package com.example.recyclerdemo2.model

data class ProfileModel(
    var fullName: String = "",
    var job: String = "",
    var popularity: Int = 0,
    var likes: Int = 0,
    var subscription: Int = 0,
    var ranking: Int = 0
)