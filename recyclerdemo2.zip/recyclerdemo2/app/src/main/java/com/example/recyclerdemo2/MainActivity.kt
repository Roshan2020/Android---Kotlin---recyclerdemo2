package com.example.recyclerdemo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.recyclerdemo2.adapter.ProfileAdapter
import com.example.recyclerdemo2.databinding.ActivityMainBinding
import com.example.recyclerdemo2.listener.Clicklistener
import com.example.recyclerdemo2.model.ProfileModel

class MainActivity : AppCompatActivity(), Clicklistener {
    var binding: ActivityMainBinding? = null
    var profileAdapter: ProfileAdapter? = null
    var profile = arrayListOf<ProfileModel>(
        ProfileModel("John Walker","Software Developer", 1000,4786, 800,1)
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        profileAdapter = ProfileAdapter(this, this)
        binding!!.rvProfile.adapter = profileAdapter
        profileAdapter!!.update(profile)
    }

    override fun onClick(position: Int) {
        Toast.makeText(this,"Option ${position +1} is clicked", Toast.LENGTH_SHORT).show()
    }
}