package com.example.recyclerdemo2.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerdemo2.databinding.ItemProfileBinding
import com.example.recyclerdemo2.listener.Clicklistener
import com.example.recyclerdemo2.model.ProfileModel

class ProfileAdapter(var context: Context, var listener: Clicklistener) : RecyclerView.Adapter<ProfileAdapter.ProfileViewHolder>(){
    var binding: ItemProfileBinding? = null
    var profile = ArrayList<ProfileModel>()
    inner class ProfileViewHolder (var itemView: ItemProfileBinding): RecyclerView.ViewHolder(itemView.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        var inflater = LayoutInflater.from(parent.context)
        binding = ItemProfileBinding.inflate(inflater, parent,false)
        return ProfileViewHolder(binding!!)
    }

    override fun getItemCount(): Int {
        return profile.size
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
        binding!!.dName.text = profile[position].fullName
        binding!!.dJob.text = profile[position].job
        binding!!.dPopularity.text = profile[position].popularity.toString()
        binding!!.dLikes.text = profile[position].popularity.toString()
        binding!!.dSubscribed.text = profile[position].subscription.toString()
        binding!!.dRanking.text = profile[position].ranking.toString()
        binding!!.btnOption.setOnClickListener{listener.onClick(position)}
    }

    fun update(list: ArrayList<ProfileModel>){
        profile = list
        notifyDataSetChanged()
    }
}

