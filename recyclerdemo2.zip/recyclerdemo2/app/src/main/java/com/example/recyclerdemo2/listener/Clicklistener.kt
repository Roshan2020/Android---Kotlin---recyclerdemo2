package com.example.recyclerdemo2.listener

interface Clicklistener {
    fun onClick(position: Int)
}